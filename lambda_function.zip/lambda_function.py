import json
import requests
import os

def lambda_handler(event, context):
    subnet_id = os.getenv('SUBNET_ID', 'your-subnet-id')

    payload = {
        "subnet_id": subnet_id,
        "name": "Sainath Kulsange",  # Replace with your full name
        "email": "sainathkulsange.@gmail# Replace with your email
    }

    api_url = "https://bc1yy8dzsg.execute-api.eu-west-1.amazonaws.com/v1/data"
    headers = {
        "X-Siemens-Auth": "test"
    }

    response = requests.post(api_url, json=payload, headers=headers)
    print(f"Response: {response.text}")
    
    return {
        'statusCode': 200,
        'body': json.dumps('Request completed successfully')
    }
